
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
 die("Connection failed: " . mysqli_connect_error());
}
else{

$sql = "SELECT * FROM rooms";

$result = mysqli_query($conn, $sql) or die("could not insert" . mysqli_error($conn));
?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">

                <div class="form-group">
                    <label>Price</label>
                    <input type="text" id="Price" class="form-control"/>

                    <label>Room Type</label>
                    <select class="form-control" id="Roomtype" name="RoomType">
                        <option>Single Room</option>
                        <option>Double Room</option>
                        <option>Triple Room</option>
                        <option>Quad Room</option>
                        <option>Queen Room</option>
                        <option>King Room</option>
                    </select>

                    <label>Available Room</label>
                    <input type="text" id="Availableroom" class="form-control"/>

                    <label>Max People</label>
                    <input type="text" id="Maxpeople" class="form-control"/>

                </div>

                <input type="hidden" id="userId" class="form-control">


            </div>
            <div class="modal-footer">
                <a href="#" id="save" class="btn btn-primary pull-right">Update</a>
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


<?php

echo '<table class="table table-striped table-responsive text-sm-center">';
echo '<thead >';
echo '<tr>';
echo '<th>Room Type</th>';
echo '<th>Avaiable Romm</th>';
echo '<th>Max People</th>';
echo '<th>Price</th>';
echo '<th>Update</th>';
echo '<th>Delete</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

while ($row = mysqli_fetch_assoc($result)){

?>
<tr id="<?php echo $row["id"]; ?>">
    <?php
    echo '<td data-target="roomtype">';
    echo $row["RoomType"];
    echo '</td>';
    echo '<td data-target="availableroom">';
    echo $row["AvailableRoom"];
    echo '</td>';
    echo '<td data-target="maxpeople">';
    echo $row["MaxPeople"];
    echo '</td>';
    echo '<td data-target="price">';
    echo $row["Price"];
    echo '</td>';
    ?>


    <td>

        <a href="#" data-role="update" data-id='<?php echo $row['id'] ?>'><i class="fas fa-wrench"></i></a>

    </td>


    <td>

        <button id="deleteM" data-id='<?php echo $row['id'] ?>'><i class="far fa-trash-alt"></i></button>

    </td>

    <?php
    echo '</tr>';


    }
    echo '</tbody>';
    echo '</table>';

    ?>
    <div id="showRoom"></div>
    <?php
    }

?>
<script>
    // append values in input fields
    
    $(document).on('click','a[data-role=update]',function(){
        var id = $(this).data('id');
        var price = $('#'+id).children('td[data-target=price]').text();
        var roomtype = $('#'+id).children('td[data-target=roomtype]').text();
        var availableroom = $('#'+id).children('td[data-target=availableroom]').text();
        var maxpeople = $('#'+id).children('td[data-target=maxpeople]').text();
//        console.log(price);
        $("#Price").val(price);
        $("#Roomtype").val(roomtype);
        $("#Availableroom").val(availableroom);
        $("#Maxpeople").val(maxpeople);
        $('#userId').val(id);
        $("#myModal").modal('toggle');

        // now create event to get data from fields and update in database 

        $('#save').click(function(){
            var id  = $('#userId').val(); 
            var RoomType =  $('#Roomtype').val();
            var Availableroom =  $('#Availableroom').val();
            var Maxpeople =  $('#Maxpeople').val();
            var Price =  $('#Price').val();
            
            

            $.ajax({
                url      : 'BackEnd/updateRooms.php',
                method   : 'post', 
                data     : {
                        RoomType : RoomType, 
                        Availableroom:Availableroom,
                        Maxpeople:Maxpeople,
                        Price:Price,
                        id: id,
                    },
                success  : function(response){
                                // now update user record in table 
                                $('#'+id).children('td[data-target=roomtype]').text(RoomType);
                                $('#'+id).children('td[data-target=availableroom]').text(Availableroom);
                                $('#'+id).children('td[data-target=maxpeople]').text(Maxpeople);
                                $('#'+id).children('td[data-target=price]').text(Price);
                                $('#myModal').modal('toggle'); 
    //                           

                            }
            });
        });
        
        
})
    
    //create event to get data from fields and update in database
     
    
</script>



 <script>
                                
    $(document).on('click','#deleteM',function(){
      
            var id  =  $(this).attr('data-id');
            //console.log(id)
            $.ajax({
                method:"get",
                url: "BackEnd/deleteRoom.php?ID",
                data:{
                    ID:id
                },
                success:function(response){
                    $('#showRoom').html(response);
                    
                },
            });                         
    })

</script>