
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
 die("Connection failed: " . mysqli_connect_error());
}
else{
         
                $sql = "SELECT * FROM manager"; 
                 
                $result = mysqli_query($conn,$sql) or die("could not insert".mysqli_error($conn));
                echo '<table class="table table-striped table-responsive text-sm-center">';
                echo '<thead >';
                echo    '<tr>';
                echo        '<th>Manager Name</th>';
                echo        '<th>Manager Email</th>';
                echo        '<th>Update</th>';
                echo        '<th>Delete</th>';
                echo    '</tr>';
                echo '</thead>';
                echo  '<tbody>';

                    while($row =  mysqli_fetch_assoc($result)){
                    
                        echo'<tr>';
                        echo  '<td>';echo $row["ManagerName"];echo '</td>';
                        echo  '<td>';echo $row["ManagerEmail"];echo '</td>';
                        ?>

                            <td>
                                <button><i class="fas fa-wrench"></i></button>
                            </td>
                             <td>
                                 
                                 <button  id="deleteM" data-id='<?php echo $row['id']?>'><i class="far fa-trash-alt"></i></button>
                                
                            </td>
                           
                        <?php
                        echo '</tr>';
                      
                        
                        
                    } 
                echo '</tbody>';
                echo'</table>';
}

?>
 <script>
                                
    $(document).on('click','#deleteM',function(){
      
            var id  =  $(this).attr('data-id')
            //console.log(id)
            $.ajax({
                method:"get",
                url: "BackEnd/deleteIndividualManager.php?ID",
                data:{
                    ID:id
                },
                success:function(response){
                    $('#showManager').html(response);
                    
                },
            });                         
    })

</script>