
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
 die("Connection failed: " . mysqli_connect_error());
}
else{
//$RoomType = $_REQUEST['RoomType'];
        //  $AvailableRoom = $_REQUEST['AvailableRoom'];
        //  $MaxPeople = $_REQUEST['MaxPeople'];
        //  $Price = $_REQUEST['Price'];
        //  $Image = $_REQUEST['Image'];

         
        //$MangerConfirmPassword = md5($_REQUEST['MangerConfirmPassword']);
        //$Admin = 'Admin';
         
         
                //  $sql1 = "SELECT * FROM admins WHERE AdminEmail = '$MangerEmail'"; 
                 
                //  $result1 = mysqli_query($conn,$sql1) or die("could not insert".mysqli_error($conn));
                //  $count = mysqli_num_rows($result1);

                //  if($count == 0){

                    // $sql ="INSERT INTO rooms(RoomType,AvailableRoom,MaxPeople,Price) VALUES ('$RoomType','$AvailableRoom','$MaxPeople','$Price')";

                    // $result = mysqli_query($conn,$sql) or die("could not insert".mysqli_error($conn));

                    // if($result)
                    // {
                    //     echo "<div class='alert alert-success'><strong>Success!</strong> Successfully Saved</div>";
                    // }
                    // else
                    // {
                    //     echo "Bingo";
                    // }

                //  }else{
                //     echo "<div class='alert alert-danger'><strong>Sorry!</strong> Email Already Existed</div>";
                //  }

                //if(isset($_REQUEST["submit"])){
                    $RoomType = $_REQUEST['RoomType'];
                    $AvailableRoom = $_REQUEST['AvailableRoom'];
                    $MaxPeople = $_REQUEST['MaxPeople'];
                    $Price = $_REQUEST['Price'];

                    $sql ="INSERT INTO rooms(RoomType,AvailableRoom,MaxPeople,Price) VALUES ('$RoomType','$AvailableRoom','$MaxPeople','$Price')";

                    $result = mysqli_query($conn,$sql) or die("could not insert".mysqli_error($conn));

                    if($result)
                    {
                        $fileName = $_FILES['img']['name'];
                        $tempName = $_FILES['img']['tmp_name'];
                        $fileType = $_FILES['img']['type'];

                        $id = mysqli_insert_id($conn);
                        $sql1= "";
                        
                        for($i=0;$i<count($tempName);$i++){
                            $name = addslashes($fileName[$i]);
                            $tmp = addslashes(file_get_contents($tempName[$i]));
                            
                            $sql1  = "insert into roomimage(rid,imagename,images) values ('$id','$name','$tmp');";
                            $result1 = mysqli_query($conn,$sql1) or die("could not insert".mysqli_error($conn));
                            if($result1){
                             echo "<div class='alert alert-success'><strong>Success!</strong> Successfully Image Saved</div>";
                            }else{
                                echo "<div class='alert alert-success'><strong>Success!</strong> Image not Saved</div>";
                            }
                            
                        }
                       
                    }else
                    {
                        echo "<div class='alert alert-success'><strong>Success!</strong> Rooms not Saved</div>";
                    }


                   
                    // echo "<pre>";
                    // print_r($fileType);
                    // echo "</pre>";
                  
                // /}
        
                 
}

?>