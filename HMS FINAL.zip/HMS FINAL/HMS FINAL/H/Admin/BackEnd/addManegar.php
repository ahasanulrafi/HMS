
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
 die("Connection failed: " . mysqli_connect_error());
}
else{
         $ManagerName = $_REQUEST['managerName'];
         $MangerEmail = $_REQUEST['mangerEmail'];
         $ManagerPassword = $_REQUEST['managerPassword'];
        //$MangerConfirmPassword = md5($_REQUEST['MangerConfirmPassword']);
        //$Admin = 'Admin';
         
         
                 $sql1 = "SELECT * FROM manager WHERE ManagerEmail = '$MangerEmail'"; 
                 
                 $result1 = mysqli_query($conn,$sql1) or die("could not insert".mysqli_error($conn));
                 $count = mysqli_num_rows($result1);

                 if($count == 0){

                    $sql ="INSERT INTO manager(ManagerName,ManagerEmail,ManagerPassword,roles) VALUES ('$ManagerName','$MangerEmail','$ManagerPassword','manager')";

                    $result = mysqli_query($conn,$sql) or die("could not insert".mysqli_error($conn));

                    if($result)
                    {
                        echo "<div class='alert alert-success'><strong>Success!</strong> Successfully Saved</div>";
                    }
                    else
                    {
                        echo "Bingo";
                    }

                 }else{
                    echo "<div class='alert alert-danger'><strong>Sorry!</strong> Email Already Existed</div>";
                 }
        
                 
}

?>