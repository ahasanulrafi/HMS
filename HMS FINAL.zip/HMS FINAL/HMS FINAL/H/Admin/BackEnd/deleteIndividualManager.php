<?php

    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "hms";
        
$conn = mysqli_connect("$servername","$username","$password","$db");
  
 if(!$conn)
    {
         die("Connection failed: " . mysqli_connect_error());
    }
    else{

            if(isset ($_GET["ID"]))
            {
                    
                     $id = $_GET["ID"];
            
                    mysqli_query($conn,"delete from admins where id=$id");
           
  
                    ?>
                            
                            
                    <script type="text/javascript">
            
                      window.location="/H/H/Admin/ViewManagers.php";
                        
                       
            
                    </script>
            <?php
                
                
            }
            
            else
            
            {
                    
                ?>
                
                       <script type="text/javascript">
            
                        window.location="/H/H/Admin/ViewManagers.php";
            
                    </script>
                
                <?php
            
            }
           
}

?>