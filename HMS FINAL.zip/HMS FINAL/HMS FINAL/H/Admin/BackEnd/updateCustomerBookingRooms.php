<?php

        $servername = "localhost";
        $username = "root";
        $password = "";
        $db = "hms";
    
       $conn = mysqli_connect("$servername","$username","$password","$db");
       
       if(!$conn)
    {
         die("Connection failed: " . mysqli_connect_error());
    }
    else{

                    $id = $_POST["id"];
                    $s_id = $_POST["stid1"];
                    echo $id ;
                    
                    $sql ="UPDATE customerbookingroom SET permission = '$s_id' where id ='$id'";
                    
                    $result = mysqli_query($conn,$sql) or die("couldnot update".mysqli_error($conn));
                    if($result)
                    {
                        echo "Data Updated";
                    }
                    else
                    {
                        echo "Bingo";       
                    }
                    
             
    }

?>