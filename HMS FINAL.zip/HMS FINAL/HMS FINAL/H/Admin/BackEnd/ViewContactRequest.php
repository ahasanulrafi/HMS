<?php
/**
 * Created by PhpStorm.
 * User: rafa
 * Date: 10-May-20
 * Time: 11:28 AM
 */

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
    die("Connection failed: " . mysqli_connect_error());
}
else{

$sql = "SELECT * FROM `contactrequest`";

$result = mysqli_query($conn, $sql) or die("could not fetch data" . mysqli_error($conn));
?>



<?php

echo '<table class="table table-striped table-responsive text-sm-center">';
echo '<thead >';
echo '<tr>';
echo '<th>Full Name</th>';
echo '<th>Email</th>';
echo '<th>Phone No.</th>';
echo '<th>Message</th>';
echo '</tr>';
echo '</thead>';
echo '<tbody>';

while ($row = mysqli_fetch_assoc($result)){

?>
<tr id="<?php echo $row["id"]; ?>">
    <?php
    echo '<td data-target="fullName">';
    echo $row["fullName"];
    echo '</td>';
    echo '<td data-target="email">';
    echo $row["email"];
    echo '</td>';
    echo '<td data-target="phoneNo">';
    echo $row["phoneNo"];
    echo '</td>';
    echo '<td data-target="message">';
    echo $row["message"];
    echo '</td>';
    ?>

    <?php
    echo '</tr>';


    }
    echo '</tbody>';
    echo '</table>';

    ?>
    <div id="showRoom"></div>
    <?php }?>

