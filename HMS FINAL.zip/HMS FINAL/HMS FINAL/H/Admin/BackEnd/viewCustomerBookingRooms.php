
<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "hms";

$conn = mysqli_connect("$servername","$username","$password","$db");

if(!$conn)
{
 die("Connection failed: " . mysqli_connect_error());
}
else{
         
                $sql = "SELECT customerbookingroom.id,customer.CustomerName,customer.CustomerEmail,customerbookingroom.room,customerbookingroom.numberofroom,customerbookingroom.checkin,customerbookingroom.checkout,customerbookingroom.adult,customerbookingroom.children,customerbookingroom.permission FROM customerbookingroom INNER JOIN customer ON customerbookingroom.cid = customer.id"; 
                 
                $result = mysqli_query($conn,$sql) or die("could not insert".mysqli_error($conn));

                ?>

                        <!-- Modal -->
                        <div id="myModal" class="modal fade" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title"></h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label>Permission</label>
                                        <select id="stid" class="form-control">
                                            <option >0</option>
                                            <option>1</option>
                                        </select>
                                    </div>
                                   
                                        <input type="hidden" id="userId" class="form-control">


                                </div>
                                <div class="modal-footer">
                                    <a href="#" id="save" class="btn btn-primary pull-right">Update</a>
                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                </div>
                                </div>

                            </div>
                        </div>   


                <?php








                echo '<table class="table table-striped table-responsive text-sm-center">';
                echo '<thead >';
                echo    '<tr>';
                echo        '<th>Customer Name</th>';
                echo        '<th>Customer Email</th>';
                echo        '<th>Room Type</th>';
                echo        '<th>Number Of Rooms</th>';
                echo        '<th>Check In</th>';
                echo        '<th>Check Out</th>';
                echo        '<th>Adult</th>';
                echo        '<th>Children</th>';
                echo        '<th>Permission</th>';
                echo        '<th>Update</th>';
                echo    '</tr>';
                echo '</thead>';
                echo  '<tbody>';

                    while($row =  mysqli_fetch_assoc($result)){
                        
                        ?>
                            <tr id ="<?php echo $row["id"] ;?>">
                        <?php
                        echo  '<td >';echo $row["CustomerName"];echo '</td>';
                        echo  '<td >';echo $row["CustomerEmail"];echo '</td>';
                        echo  '<td >';echo $row["room"];echo '</td>';
                        echo  '<td>';echo $row["numberofroom"];echo '</td>';
                        echo  '<td>';echo $row["checkin"];echo '</td>';
                        echo  '<td>';echo $row["checkout"];echo '</td>';
                        echo  '<td>';echo $row["adult"];echo '</td>';
                        echo  '<td>';echo $row["children"];echo '</td>';
                        echo  '<td data-target="stid">';echo $row["permission"];echo '</td>';
                        ?>

                           
                             <td>
                                 
                                 <a  href="#" data-role="update" data-id='<?php echo $row['id']?>'><i class="fas fa-wrench"></i></a>
                                
                            </td>
                           
                        <?php
                        echo '</tr>';
                      
                        
                        
                    } 
                echo '</tbody>';
                echo'</table>';

                ?>
                    <div id="showRoom"></div>
                <?php
}

?>

<script>
  $(document).ready(function(){

    //  append values in input fields
      $(document).on('click','a[data-role=update]',function(){
            var id  = $(this).data('id');
            var stid  = $('#'+id).children('td[data-target=stid]').text();

            $('#stid').val(stid);
            $('#userId').val(id);
            $('#myModal').modal('toggle');
      });

      // now create event to get data from fields and update in database 

       $('#save').click(function(){
          var id  = $('#userId').val(); 
         var stid1 =  $('#stid').val();
        

          $.ajax({
              url      : 'BackEnd/updateCustomerBookingRooms.php',
              method   : 'post', 
              data     : {stid1 : stid1 , id: id},
              success  : function(response){
                            // now update user record in table 
                              $('#'+id).children('td[data-target=stid]').text(stid1);
                              $('#myModal').modal('toggle'); 
//                           

                         }
          });
       });
  });
</script>



<!-- 
 <script>
                                
    $(document).on('click','#deleteM',function(){
      
            var id  =  $(this).attr('data-id')
            //console.log(id)
            $.ajax({
                method:"get",
                url: "BackEnd/updateCustomerBookingRooms.php?ID",
                data:{
                    ID:id
                },
                success:function(response){
                    $('#showRoom').html(response);
                    
                },
            });                         
    })

</script> -->