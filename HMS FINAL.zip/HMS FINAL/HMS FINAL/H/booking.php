<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HotelBooking.com</title>
    <link rel="stylesheet"  type="text/css" href="css/style.css">
<style>
       #s4{
	background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url('../images/booking.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    height: 100vh;
}
        body{
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;;
            font-size: 20px;
            color: black;
            overflow-x: hidden;
        }

        form {
            margin: 0 auto;
            width: 600px;
            padding: 1em;
            border: 1px solid #CCC;
            border-radius: 1em;
            position: fixed;
            top: 50%;
            left: 50%;
            margin-top: -100px;
            margin-left: -200px;
            background-color: #ffff;
           
        }

        input[type=date]{
            width: 250px;
            border: 2px solid #aaa;
            border-radius: 4px;
            margin: 8px 0;
            outline: none;
            padding:8px;
        }
        
        select{
            width: 100px;
            border: 2px solid #aaa;
            border-radius: 4px;
            margin: 8px 0;
            outline: none;
            padding:8px;
        }

        #div{
            margin: 0;
            padding: 0;
            height: 50px;
            width: 100%;
        }

    </style>
</head>
<body>
    <header>
        <nav>
			<div class="row clearfix">
				<label class="logo">
                    HotelBooking.com
                </label>

				<ul class="main-nav animated slideInDown" id="check-class">
					<li><a href="homepage.php">Home</a></li>
					<?php
					
                        if(isset($_SESSION["Pattern"]) && $_SESSION["Pattern"]="customer"){
						
						}else{
							?>
							<li><a href="createaccount.php">Create Account</a></li>
							<?php
						}
                    ?>
                     <?php
					
                        if(isset($_SESSION["Pattern"]) && $_SESSION["Pattern"]="customer"){
                            ?>
                                <li>
                                    <a class="active" href="booking.php">Your Booking </a>
                                </li> 
                            <?php
                        }else{
                           
                            
                           
                        }
                    ?>
					
                    <?php
					
                        if(isset($_SESSION["Pattern"]) && $_SESSION["Pattern"]="customer"){
						
						}else{
							?>
							<li><a href="signin.php">Sign in</a></li>
							<?php
						}
					?>
					
                </ul>
                
				<a href="#" class="mobile-icon"  onclick="slideshow()"> <i class="fa fa-bars"></i> </a>
			</div>
		</nav> 


        <form action="" method="post">
            <table>
                <tr align="left">
                    <th><label for="check-in">Check-in</label></th>
                    <th><label for="check-out">Check-out</label></th>
                </tr>
                <tr>
                    <th><input type="date" name="" id=""></th>
                    <th><input type="date" name="" id=""></th>
                    <th align="right"><img src="images/home.png" alt=""></th>
                </tr>
                <tr align="left">
                    <td style="font-size: 15px">day</td>
                    <td style="font-size: 15px">day</td>
                </tr>
            </table>
            <hr>
            <table width="500">
                <tr>
                    <th>Rooms</th>
                    <th>Adults</th>
                    <th>Children</th>
                </tr>
                <tr>
                    <th >
                        <select name="room">
                            <option value="">select</option>
                        </select> <br>
                        <label for="" style="font-size: 15px"> Room </label>
                    </th>
                    <th>
                        <select name="adults" id="">
                            <option value="">select</option>
                        </select> <br>
                        <label for="" style="font-size: 15px"> Aged 18+ </label>
                    </th>
                    <th>
                        <select name="adults" id="">
                            <option value="">Children</option>
                        </select> <br>
                        <label for="" style="font-size: 15px"> 0-17 </label>
                    </th>
                </tr>
				            <table width="500">
                <tr>
                    <th><label for="price">Price:(Tk)</label></th>
                    <th><input type="text" placeholder="Per Night" name="" id=""></th>
					
					
                </tr>
            </table>
            <hr>
           <div id="div" align="right">
                <input  class="button" type="button" value="Search"> 
           </div>
        
        </form>


    </header>   

</body>
</html>